package com.sunbeam;

import java.util.*;

public class StudentCourseRegistrationSystem {
    private static ArrayList<Student> students = new ArrayList<>();
    private static ArrayList<Course> courses = new ArrayList<>();
    private static ArrayList<Registration> registrations = new ArrayList<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n===== Student Course Registration System =====");
            System.out.println("1. Add Student");
            System.out.println("2. Add Course");
            System.out.println("3. Register Student for Course");
            System.out.println("4. Display All Students");
            System.out.println("5. Display All Courses");
            System.out.println("6. View Students by Course Name");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            try {
                switch (choice) {
                    case 1:
                        System.out.println("Enter Student Id: ");
                        int sid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Student Name: ");
                        String sname = sc.nextLine();
                        System.out.print("Enter Student Email: ");
                        String email = sc.nextLine();
                        students.add(new Student(sid, sname, email));
                        System.out.println("Student added successfully!");
                        break;

                    case 2:
                        System.out.println("Enter Course Id: ");
                        int cid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Course Title: ");
                        String title = sc.nextLine();
                        System.out.print("Enter Marks: ");
                        int credits = sc.nextInt();
                        courses.add(new Course(cid, title, credits));
                        System.out.println("Course added successfully!");
                        break;

                    case 3:
                        System.out.print("Enter Registration Id: ");
                        int registerId = sc.nextInt();
                        System.out.print("Enter Student Id: ");
                        int studentId = sc.nextInt();
                        System.out.print("Enter Course Id: ");
                        int courseId = sc.nextInt();
                        if (findStudentById(studentId) == null)
                            throw new RecordNotFoundException("Student not found!");
                        if (findCourseById(courseId) == null)
                            throw new RecordNotFoundException("Course not found!");

                        registrations.add(new Registration(registerId, studentId, courseId));
                        System.out.println("Registration successful!");
                        break;

                    case 4:
                        if (students.isEmpty())
                            throw new RecordNotFoundException("No students found!");
                        System.out.println("---- All Students ----");
                        for (Student s : students) {
                            System.out.println(s);
                        }
                        break;

                    case 5:
                        if (courses.isEmpty())
                            throw new RecordNotFoundException("No courses found!");
                        System.out.println("---- All Courses ----");
                        for (Course c : courses) {
                            System.out.println(c);
                        }
                        break;

                    case 6:
                        System.out.print("Enter Course Name: ");
                        String cname = sc.nextLine();
                        Course courseObj = findCourseByName(cname);
                        if (courseObj == null)
                            throw new RecordNotFoundException("Course not found!");

                        System.out.println("Students registered in course " + cname + ":");
                        boolean found = false;
                        for (Registration r : registrations) {
                            if (r.getCourseId() == courseObj.getCourseId()) {
                                Student s = findStudentById(r.getStudentId());
                                if (s != null) {
                                    System.out.println(s);
                                    found = true;
                                }
                            }
                        }
                        if (!found)
                            throw new RecordNotFoundException("No students registered in this course!");
                        break;

                    case 7:
                        System.out.println("Exiting program... Goodbye!");
                        break;

                    default:
                        System.out.println("Invalid choice! Try again.");
                }
            } catch (RecordNotFoundException e) {
                System.out.println(" Error: " + e.getMessage());
            }

        } while (choice != 7);

        sc.close();
    }


    private static Student findStudentById(int id) {
        for (Student s : students) {
            if (s.getStudentId() == id) return s;
        }
        return null;
    }

    private static Course findCourseById(int id) {
        for (Course c : courses) {
            if (c.getCourseId() == id) return c;
        }
        return null;
    }

    private static Course findCourseByName(String name) {
        for (Course c : courses) {
            if (c.getTitle().equalsIgnoreCase(name)) return c;
        }
        return null;
    }
}
