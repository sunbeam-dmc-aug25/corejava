package com.sunbeam;

public class Course {
    private int courseId;
    private String title;
    private int marks;

    public Course(int courseId, String title, int marks) {
        this.courseId = courseId;
        this.title = title;
        this.marks = marks;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return "CourseId: " + courseId + ", Title: " + title + ", marks: " + marks;
    }
}
